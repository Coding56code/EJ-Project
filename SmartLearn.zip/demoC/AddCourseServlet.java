package demoC;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

public class AddCourseServlet extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String courseName = request.getParameter("courseName");
        String courseDescription = request.getParameter("courseDescription");
        String instructorName = request.getParameter("instructorName");
        int duration = Integer.parseInt(request.getParameter("duration"));

        try {

            Class.forName("com.mysql.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CourseDB", "root", "root");

            PreparedStatement pst = con.prepareStatement("INSERT INTO courses (course_name, course_description, instructor_name, duration) VALUES (?, ?, ?, ?)");
            pst.setString(1, courseName);
            pst.setString(2, courseDescription);
            pst.setString(3, instructorName);
            pst.setInt(4, duration);

            int row = pst.executeUpdate();
            if (row == 1) {
                out.println("Course Name : " + courseName + " added successfully");
            } else {
                out.println("Course cannot be added");
            }

        } catch (Exception e) {
            out.println("Error : " + e);
        }
    }
}
