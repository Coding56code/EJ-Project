package demoR;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class RegisterServlet extends HttpServlet {

    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/RegDB", "root", "root");
            PreparedStatement pst = con.prepareStatement("insert into users values(?,?,?)");
            pst.setString(1, username);
            pst.setString(2, email );
            pst.setString(3, password);

            int row = pst.executeUpdate();
            if (row == 1) {
                out.println("Details of " + username + " added successfully");
            } else {
                out.println("Details cannot be added");
            }

        } catch (Exception e) {
            out.println("Error : " + e);
        }
    }
}
